package cn.mvp.global;

public class Constant {
    // 周期性的闹钟
    public final static String TIMER_ACTION_REPEATING = "com.e_eduspace.timer_action_repeating";
    // 定时闹钟
    public final static String TIMER_ACTION = "com.e_eduspace.timer_action";

    public static final int REQUEST_CODE_SCAN_QRCODE = 001;
    public static final String SP_KEY_WEBSOCKET_ADDRESS = "websocket_address";
    /*二维码快捷方式id*/
    public static final String SHORTCUT_ID_EWM = "1122";
}
