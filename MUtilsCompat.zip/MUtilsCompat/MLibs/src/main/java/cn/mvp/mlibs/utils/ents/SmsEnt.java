package cn.mvp.mlibs.utils.ents;

public class SmsEnt {
    private String id;
    private String address;
    private String person;
    private String body;
    private String date;
    /** 接收或发送 */
    private String type;
}
