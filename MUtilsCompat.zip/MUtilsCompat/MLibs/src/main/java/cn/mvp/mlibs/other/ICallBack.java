package cn.mvp.mlibs.other;

/**
 * 通用回调方法
 */
public interface ICallBack {
    void back();
}
