package cn.mvp.mlibs.weight;

import android.view.View;

public interface ItemWeightClick {
    void onItemWeightClick(View view, int pos);
}
