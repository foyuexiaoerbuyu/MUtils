package com.itxiaox.android.xutils.fun.callback;


/**
 * 无参回调接口
 * test ok
 * @param <R>
 */
public interface RXAction<R>{
    R doAction();
}
